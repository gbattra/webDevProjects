//angular app file

var app = angular.module('EquisolveApp', []);


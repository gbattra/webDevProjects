//service for app

app.factory('getNews', ['$http', function ($http) { 
  return $http.get('http://www.stellarbiotechnologies.com/media/press-releases/json')
  			.success(function (data) { 
              return data; 
            }) 
            .error(function (err) { 
              return err; 
            }); 
}]);
